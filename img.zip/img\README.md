# GIF de loading do overlay global (substitua pelo teu `loading.gif` animado).
# Formato esperado pelo `angular.json` e pelo `frontend/Dockerfile`.
